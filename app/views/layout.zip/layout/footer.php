    </div>
  </div>
</main>
<footer class="app-footer">
  <div class="float-end d-none d-sm-inline">Galería</div>
  <strong>&copy; <?= date('Y') ?>.</strong> Todos los derechos reservados.
</footer>
</div>
