<?php
/** @var string|null $pageTitle */
$title = $pageTitle ?? 'Galería';
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title><?= htmlspecialchars($title) ?> | Galería</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5/index.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2/styles/overlayscrollbars.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1/font/bootstrap-icons.min.css" />
  <link rel="stylesheet" href="<?= htmlspecialchars(asset('adminlte/css/adminlte.min.css')) ?>" />
</head>
<body class="layout-fixed fixed-header fixed-footer sidebar-expand-lg sidebar-open bg-body-tertiary">

<div class="app-wrapper">
  <nav class="app-header navbar navbar-expand bg-body">
    <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button"><i class="bi bi-list"></i></a>
        </li>
        <li class="nav-item d-none d-md-block">
          <a href="<?= htmlspecialchars(BASE_URL) ?>/index.php" class="nav-link">Inicio</a>
        </li>
      </ul>

      <ul class="navbar-nav ms-auto">
        <li class="nav-item d-none d-md-flex align-items-center">
          <span class="nav-link text-secondary">
            <?= htmlspecialchars($_SESSION['username'] ?? '') ?>
            <?= ($_SESSION['rol'] ?? null) ? '• ' . htmlspecialchars((string)$_SESSION['rol']) : '' ?>
          </span>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= htmlspecialchars(BASE_URL) ?>/logout.php" title="Salir">
            <i class="bi bi-box-arrow-right"></i>
          </a>
        </li>
      </ul>
    </div>
  </nav>
