<?php
$rol = $_SESSION['rol'] ?? '';
?>

<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
  <div class="sidebar-brand">
    <a href="<?= htmlspecialchars(BASE_URL) ?>/index.php" class="brand-link">
      <span class="brand-text fw-light">Galería</span>
    </a>
  </div>

  <div class="sidebar-wrapper">
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column"
          data-lte-toggle="treeview"
          role="menu"
          data-accordion="false">
        <li class="nav-item">
          <a href="<?= htmlspecialchars(BASE_URL) ?>/index.php" class="nav-link">
            <i class="nav-icon bi bi-speedometer"></i>
            <p>Dashboard</p>
          </a>
        </li>
  
        <?php if ($rol === 'COCHERA' || $rol === 'ADMIN'): ?>
<li class="nav-item">
  <a href="#" class="nav-link" data-bs-toggle="collapse" data-bs-target="#submenuCochera" aria-expanded="false">
    <i class="nav-icon bi bi-car-front"></i>
    <p>
      Cochera
      <i class="nav-arrow bi bi-chevron-right"></i>
    </p>
  </a>
  <ul class="nav nav-treeview collapse" id="submenuCochera">
    <li class="nav-item">
      <a href="<?= htmlspecialchars(BASE_URL) ?>/index.php?c=cochera&a=entrada" class="nav-link">
        <i class="nav-icon bi bi-circle"></i>
        <p>Entrada</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="<?= htmlspecialchars(BASE_URL) ?>/index.php?c=cochera&a=salida" class="nav-link">
        <i class="nav-icon bi bi-circle"></i>
        <p>Salida</p>
      </a>
    </li>
  </ul>
</li>
<?php endif; ?>
     <?php if ($rol === 'BANOS' || $rol === 'ADMIN'): ?>
          <li class="nav-item">
            <a href="<?= htmlspecialchars(BASE_URL) ?>/index.php?c=banos&a=index" class="nav-link">
              <i class="nav-icon bi bi-droplet"></i>
              <p>Baños</p>
            </a>
          </li>
        <?php endif; ?>

        <?php if ($rol === 'ALQUILERES' || $rol === 'ADMIN'): ?>
  <li class="nav-item">
    <a href="#" class="nav-link" data-bs-toggle="collapse" data-bs-target="#submenuAlquileres" aria-expanded="false">
      <i class="nav-icon bi bi-shop"></i>
      <p>
        Alquileres
        <i class="nav-arrow bi bi-chevron-right"></i>
      </p>
    </a>

    <ul class="nav nav-treeview collapse" id="submenuAlquileres">
      <li class="nav-item">
        <a href="<?= htmlspecialchars(BASE_URL) ?>/index.php?c=alquileres&a=stands" class="nav-link">
          <i class="nav-icon bi bi-circle"></i>
          <p>Stands</p>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= htmlspecialchars(BASE_URL) ?>/index.php?c=alquileres&a=inquilinos" class="nav-link">
          <i class="nav-icon bi bi-circle"></i>
          <p>Inquilinos</p>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= htmlspecialchars(BASE_URL) ?>/index.php?c=alquileres&a=contratos" class="nav-link">
          <i class="nav-icon bi bi-circle"></i>
          <p>Contratos</p>
        </a>
      </li>
    </ul>
  </li>
<?php endif; ?>

   

        <?php if ($rol === 'TESORERIA' || $rol === 'ADMIN'): ?>
          <li class="nav-item">
            <a href="<?= htmlspecialchars(BASE_URL) ?>/index.php?c=tesoreria&a=index" class="nav-link">
              <i class="nav-icon bi bi-cash-coin"></i>
              <p>Tesorería</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?= htmlspecialchars(BASE_URL) ?>/index.php?c=reportes&a=index" class="nav-link">
              <i class="nav-icon bi bi-graph-up"></i>
              <p>Reportes</p>
            </a>
          </li>
        <?php endif; ?>
      </ul>
    </nav>
  </div>
</aside>

<main class="app-main">
  <div class="app-content-header">
    <div class="container-fluid">
      <h3 class="mb-0"><?= htmlspecialchars($pageTitle ?? 'Dashboard') ?></h3>
    </div>
  </div>
  <div class="app-content">
    <div class="container-fluid">

